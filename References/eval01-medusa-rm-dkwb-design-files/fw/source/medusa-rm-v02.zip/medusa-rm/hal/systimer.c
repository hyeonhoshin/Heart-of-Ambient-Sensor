/*
 * systimer.c
 *
 *  Created on: 22 may. 2017
 *      Author: IbonZalbide
 */
#include <msp430.h>
#include "../definitions/typedefs.h"
#include "../definitions/configuration.h"
#include "systimer.h"

extern unsigned short lpm_status;
extern r100DemoConf_t r100DemoConf;

bool fSysTick = false;


void init_systimer()
{
    //WDTCTL = WDTPW | WDTCNTCL | WDTTMSEL | WDTSSEL__VLO | r100DemoConf.timerInterval; // Set Watchdog Timer timeout 800ms
    WDTCTL = WDTPW | WDTCNTCL | WDTTMSEL | WDTSSEL__VLO | WDTIS__512; // Set Watchdog Timer timeout 800ms
    SFRIE1 |= WDTIE;                        // Enable WDT interrupt
}

// Watchdog Timer interrupt service routine
#pragma vector = WDT_VECTOR
__interrupt void WDT_ISR(void)
{
    fSysTick = true;
    // Exit low power mode
    _BIC_SR_IRQ(lpm_status);
}

