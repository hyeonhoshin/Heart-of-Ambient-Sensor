/*
 * adc.c
 *
 *  Created on: 22 may. 2017
 *      Author: IbonZalbide
 */
#include <msp430.h>
#include "../definitions/typedefs.h"
#include "adc.h"
#include "mcu.h"

uint16_t adc_result=0;
bool fAdcDone=false;

// LPM state word
unsigned short lpm_status;

void adc_init(void) {
    // Configure ADC A6 pin
    P1DIR &=  ~ADC_BIT;
    SYSCFG2 |= ADCPCTL6;

    // Configure ADC10
    ADCCTL0 |= ADCSHT_2 | ADCON;                             // ADCON, S&H=16 ADC clks
    ADCCTL1 |= ADCSHP;                                       // ADCCLK = MODOSC; sampling timer
    ADCCTL2 |= ADCRES;                                       // 10-bit conversion results
    ADCMCTL0 |= ADCINCH_6;                                   // A1 ADC input select; Vref=AVCC
    ADCIE |= ADCIE0;                                         // Enable ADC conv complete interrupt
}

uint16_t adc_read(void) {
  // Start ADC reading
  fAdcDone=false;
  ADCCTL0 |= ADCENC | ADCSC;                           // Sampling and conversion start

  // Wait while conversion is active
  while(!fAdcDone)
  {
      mcu_lpm_enter(0);
  }

  return adc_result;
}

// ADC interrupt service routine
#pragma vector=ADC_VECTOR
__interrupt void ADC_ISR(void)

{
    switch(__even_in_range(ADCIV,ADCIV_ADCIFG))
    {
        case ADCIV_NONE:
            break;
        case ADCIV_ADCOVIFG:
            break;
        case ADCIV_ADCTOVIFG:
            break;
        case ADCIV_ADCHIIFG:
            break;
        case ADCIV_ADCLOIFG:
            break;
        case ADCIV_ADCINIFG:
            break;
        case ADCIV_ADCIFG:
            adc_result = ADCMEM0;
            fAdcDone=true;
        	_BIC_SR_IRQ(lpm_status);
            break;
        default:
            break;
    }
}

