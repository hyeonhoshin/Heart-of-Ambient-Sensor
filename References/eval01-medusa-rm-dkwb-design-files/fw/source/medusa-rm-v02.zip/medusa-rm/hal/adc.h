#ifndef __ADC_H
#define __ADC_H

#include "../definitions/typedefs.h"

#define ADC_BIT				BIT6

void adc_init(void);
uint16_t adc_read(void);

#endif
