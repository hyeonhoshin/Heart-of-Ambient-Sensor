#include <msp430.h>
#include "definitions/typedefs.h"
#include "definitions/configuration.h"
#include "hal/mcu.h"
#include "hal/rocky100.h"
#include "hal/systimer.h"
#include "hal/adc.h"

#define clockFreq 52

#pragma PERSISTENT(r100DemoConf)
r100DemoConf_t r100DemoConf = {
                               .nSysTicksPerSample = 1,
                               .DataRateMs = 70
};


extern bool fR100;
extern bool fSysTick;
extern uint8_t r100_rx_buf[128];


uint16_t SysTickCounter = 0;

void check_rx_buffer();

void main(void)
{
    // Initialize MCU
    init_watchdog();
    init_clocks();
    init_gpios();

    // Initialize peripherals
    init_rocky100();
    adc_init();

    // Release MCU gpios
    release_gpios();

    __bis_SR_register(GIE);

    // Load configuration
    // Configure sensor
    init_systimer();

    fSysTick = true;
    while (1)
    {

        if (fSysTick == true)
        {
            // Reset timer flag
            fSysTick = false;
            if (++SysTickCounter >= r100DemoConf.nSysTicksPerSample)
            {
                SysTickCounter = 0;
                rocky100_update_data(adc_read());
            }
        }

        if (fR100 == true)
        {
            // Reset timer flag
            fR100 = false;

            // Check rx_buffer
            check_rx_buffer();

            // Reset SPI
            reset_rocky100_spi();

        }

        if (rocky100_is_idle())
        {
            mcu_lpm_enter(4);
        }else{
            mcu_lpm_enter(0);
        }
    }
}


void check_rx_buffer(){

    if( r100_rx_buf[0] == SETRATE){

        SYSCFG0 = FRWPPW | DFWP;            // Program FRAM write enable
        r100DemoConf.DataRateMs = r100_rx_buf[2] + (r100_rx_buf[1] << 8);

        r100DemoConf.nSysTicksPerSample = (int)((1.0*r100DemoConf.DataRateMs / clockFreq)+0.5);

        SYSCFG0 = FRWPPW | PFWP | DFWP;     // Program FRAM write protected (not writable)

        rocky100_load_rate();
    }
}
